from enum import Enum
from typing import List, Optional, Dict
from pydantic import BaseModel, Field


class DifficultyLevel(str, Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class DocumentUploadResponse(BaseModel):
    document_id: str
    filename: str
    file_type: str
    num_chunks: int
    message: str


class QuestionFormat(BaseModel):
    count: int = Field(..., ge=0, le=20, description="Number of questions of this type")
    marks: int = Field(..., ge=1, le=20, description="Marks per question")


class QuestionGenerationRequest(BaseModel):
    topic: Optional[str] = Field(None, description="Specific topic to focus on")
    difficulty: DifficultyLevel = Field(DifficultyLevel.MEDIUM, description="Difficulty level")
    num_questions: int = Field(5, ge=1, le=50, description="Number of questions to generate")
    question_types: Optional[List[str]] = Field(
        None,
        description="Types of questions (very_short_answer, short_answer, long_answer)"
    )
    use_context: bool = Field(True, description="Whether to use uploaded documents as context")
    bloom_distribution: Optional[Dict[str, int]] = Field(
        None,
        description="Bloom's taxonomy distribution percentages"
    )
    question_format: Optional[Dict[str, QuestionFormat]] = Field(
        None,
        description="Format for each question type with count and marks"
    )
    instructions: Optional[str] = Field(None, description="Additional instructions for paper generation")
    subject: Optional[str] = Field(None, description="Subject for the question paper")


class Question(BaseModel):
    question_number: int
    question_text: str
    question_type: str
    difficulty: DifficultyLevel
    marks: int
    sample_answer: Optional[str] = None
    context_source: Optional[str] = None


class QuestionPaper(BaseModel):
    title: str
    subject: Optional[str] = None
    difficulty: DifficultyLevel
    total_marks: int
    questions: List[Question]
    instructions: Optional[str] = None
    generated_at: Optional[str] = None


class EmbeddingResponse(BaseModel):
    success: bool
    num_documents: int
    num_chunks: int
    message: str


class HealthResponse(BaseModel):
    status: str
    version: str


# Course Structure Models
class Subject(BaseModel):
    id: str
    name: str
    code: str
    description: Optional[str] = None
    created_at: str
    updated_at: str


class Unit(BaseModel):
    id: str
    subject_id: str
    name: str
    description: Optional[str] = None
    order: int
    created_at: str
    updated_at: str


class Lesson(BaseModel):
    id: str
    unit_id: str
    name: str
    description: Optional[str] = None
    order: int
    learning_objectives: Optional[List[str]] = None
    created_at: str
    updated_at: str


# Create Models
class SubjectCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    code: str = Field(..., min_length=1, max_length=20)
    description: Optional[str] = Field(None, max_length=500)


class UnitCreate(BaseModel):
    subject_id: str
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    order: int = Field(1, ge=1)


class LessonCreate(BaseModel):
    unit_id: str
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    order: int = Field(1, ge=1)
    learning_objectives: Optional[List[str]] = Field(None, max_items=10)
