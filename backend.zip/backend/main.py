from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from typing import List, Optional
import os
import uuid
import shutil
from datetime import datetime

from config import settings
from models import (
    DocumentUploadResponse,
    QuestionGenerationRequest,
    QuestionPaper,
    EmbeddingResponse,
    HealthResponse,
    DifficultyLevel,
    Subject,
    Unit,
    Lesson,
    SubjectCreate,
    UnitCreate,
    LessonCreate
)
from services.rag_service import RAGService
from services.question_generation import QuestionGenerationService
from services.contextual_embedding import ContextualEmbeddingService
from utils.document_processor import DocumentProcessor

# Initialize FastAPI app
app = FastAPI(
    title=settings.api_title,
    version=settings.api_version,
    description="API for generating question papers using RAG and LLM"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
static_dir = os.path.join(os.path.dirname(__file__), "static")
print(f"Static directory: {static_dir}")
print(f"Static directory exists: {os.path.exists(static_dir)}")

if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")
    print("Static files mounted successfully")
else:
    print("Warning: Static directory not found")

# Static file endpoints for debugging
@app.get("/js/app.js")
async def serve_js():
    js_file = os.path.join(static_dir, "js", "app.js")
    if os.path.exists(js_file):
        return FileResponse(js_file, media_type="application/javascript")
    return {"error": "JavaScript file not found"}

@app.get("/css/{file_name}")
async def serve_css(file_name: str):
    css_file = os.path.join(static_dir, "css", file_name)
    if os.path.exists(css_file):
        return FileResponse(css_file, media_type="text/css")
    return {"error": "CSS file not found"}

# Root endpoint to serve the frontend
@app.get("/", response_class=HTMLResponse)
async def read_root():
    static_file = os.path.join(static_dir, "index.html")
    if os.path.exists(static_file):
        return FileResponse(static_file)
    return HTMLResponse("""
    <html>
        <head><title>Paperly API</title></head>
        <body>
            <h1>Paperly Question Generation API</h1>
            <p>API is running. Visit <a href="/docs">/docs</a> for API documentation.</p>
        </body>
    </html>
    """)

# Initialize services
rag_service = RAGService()
question_service = QuestionGenerationService()
contextual_embedding_service = ContextualEmbeddingService()
document_processor = DocumentProcessor()

# Store uploaded documents metadata
uploaded_documents = {}

# Store course structure data
subjects = {}
units = {}
lessons = {}


@app.get("/", response_model=HealthResponse)
async def root():
    """Health check endpoint."""
    return HealthResponse(
        status="healthy",
        version=settings.api_version
    )


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Detailed health check."""
    return HealthResponse(
        status="healthy",
        version=settings.api_version
    )


@app.post("/upload-document", response_model=DocumentUploadResponse)
async def upload_document(file: UploadFile = File(...)):
    """
    Upload a document (PDF, PPTX) for question generation.
    The document will be processed, embedded, and stored for retrieval.
    """
    # Check file extension
    _, ext = os.path.splitext(file.filename)
    if ext.lower() not in document_processor.get_supported_extensions():
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format. Supported formats: {document_processor.get_supported_extensions()}"
        )
    
    # Generate unique document ID
    doc_id = str(uuid.uuid4())
    
    # Save uploaded file
    file_path = os.path.join(settings.upload_dir, f"{doc_id}{ext}")
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error saving file: {str(e)}")
    
    # Extract text from document
    try:
        text_content = document_processor.extract_text(file_path)
    except Exception as e:
        os.remove(file_path)  # Clean up
        raise HTTPException(status_code=400, detail=f"Error processing document: {str(e)}")
    
    # Generate contextual embeddings (optional enhancement)
    try:
        enriched_text = contextual_embedding_service.generate_contextual_embedding(
            text_content[:5000]  # Limit for API
        )
        # Combine original and enriched text
        final_text = f"{text_content}\n\n--- AI Analysis ---\n{enriched_text}"
    except Exception as e:
        print(f"Warning: Could not generate contextual embedding: {e}")
        final_text = text_content
    
    # Add to RAG system
    try:
        num_chunks = rag_service.add_documents(
            texts=[final_text],
            metadatas=[{
                "document_id": doc_id,
                "filename": file.filename,
                "file_type": ext
            }]
        )
    except Exception as e:
        os.remove(file_path)  # Clean up
        raise HTTPException(status_code=500, detail=f"Error indexing document: {str(e)}")
    
    # Store metadata
    uploaded_documents[doc_id] = {
        "filename": file.filename,
        "file_path": file_path,
        "file_type": ext,
        "num_chunks": num_chunks
    }
    
    return DocumentUploadResponse(
        document_id=doc_id,
        filename=file.filename,
        file_type=ext,
        num_chunks=num_chunks,
        message="Document uploaded and indexed successfully"
    )


@app.post("/upload-documents", response_model=List[DocumentUploadResponse])
async def upload_multiple_documents(files: List[UploadFile] = File(...)):
    """Upload multiple documents at once."""
    results = []
    for file in files:
        try:
            result = await upload_document(file)
            results.append(result)
        except HTTPException as e:
            # Continue with other files but log error
            print(f"Error uploading {file.filename}: {e.detail}")
    
    if not results:
        raise HTTPException(status_code=400, detail="No documents were successfully uploaded")
    
    return results


@app.post("/generate-questions", response_model=QuestionPaper)
async def generate_questions(request: QuestionGenerationRequest):
    """
    Generate a question paper based on the request parameters.
    If use_context is True, uses uploaded documents for context.
    """
    context_documents = []

    if request.use_context:
        # Retrieve relevant context from RAG
        query = request.topic or "Generate educational questions from the study materials"
        context_documents = rag_service.retrieve_context(
            query=query,
            k=settings.retrieval_k
        )

        if not context_documents:
            raise HTTPException(
                status_code=400,
                detail="No documents available. Please upload documents first or set use_context to False."
            )

    # Build enhanced prompt with Bloom's taxonomy and question format
    prompt_parts = []

    # Basic information
    prompt_parts.append(f"Generate a question paper for: {request.topic or 'General subject'}")
    if request.subject:
        prompt_parts.append(f"Subject: {request.subject}")
    if request.difficulty:
        prompt_parts.append(f"Difficulty level: {request.difficulty}")

    # Question format specification
    if request.question_format:
        format_description = []
        for q_type, format_info in request.question_format.items():
            if format_info.count > 0:
                type_name = q_type.replace('_', ' ').title()
                format_description.append(
                    f"{format_info.count} {type_name} questions ({format_info.marks} marks each)"
                )

        if format_description:
            prompt_parts.append("Question format: " + "; ".join(format_description))

    # Bloom's taxonomy distribution
    if request.bloom_distribution:
        bloom_parts = []
        for level, percentage in request.bloom_distribution.items():
            if percentage > 0:
                bloom_parts.append(f"{level} ({percentage}%)")

        if bloom_parts:
            prompt_parts.append("Bloom's taxonomy distribution: " + "; ".join(bloom_parts))

    # Question types
    if request.question_types:
        type_names = [t.replace('_', ' ').replace('very short', 'very short') for t in request.question_types]
        prompt_parts.append("Question types: " + ", ".join(type_names))

    # Instructions
    if request.instructions:
        prompt_parts.append(f"Additional instructions: {request.instructions}")

    # Add context information if available
    if context_documents:
        context_text = "\n\n--- Context from uploaded documents ---\n"
        for i, doc in enumerate(context_documents[:3], 1):  # Use top 3 documents
            context_text += f"\nDocument {i}:\n{doc.page_content[:1000]}...\n"
        prompt_parts.append(context_text)

    # Add detailed JSON formatting instructions
    prompt_parts.append("\n\nIMPORTANT INSTRUCTIONS:")
    prompt_parts.append(f"1. Generate EXACTLY {request.num_questions} questions")
    prompt_parts.append("2. Return ONLY a valid JSON array - no other text")
    prompt_parts.append("3. Use question types: " + ", ".join(request.question_types or ["short_answer"]))
    prompt_parts.append("4. Each question must include all required fields")
    prompt_parts.append("""
Expected JSON format:
[
  {
    "question_number": 1,
    "question_text": "Clear, well-formed question text",
    "question_type": "very_short_answer",
    "difficulty": "medium",
    "marks": 2,
    "sample_answer": "Brief answer or key points"
  },
  {
    "question_number": 2,
    "question_text": "Next question...",
    "question_type": "short_answer",
    "difficulty": "medium",
    "marks": 5,
    "sample_answer": "Answer details..."
  }
]""")
    prompt_parts.append(f"CRITICAL: Generate exactly {request.num_questions} questions in valid JSON format.")

    full_prompt = "\n".join(prompt_parts)

    # Generate questions
    try:
        question_paper = question_service.generate_questions(
            topic=request.topic,
            difficulty=request.difficulty,
            num_questions=request.num_questions,
            question_types=request.question_types,
            context_documents=context_documents,
            custom_prompt=full_prompt
        )

        # Set the title and subject in the response
        if request.subject:
            question_paper.title = f"{request.subject} Question Paper"
        elif request.topic:
            question_paper.title = f"Question Paper: {request.topic}"

        # Calculate total marks based on format if provided
        if request.question_format:
            total_marks = sum(
                format_info.count * format_info.marks
                for format_info in request.question_format.values()
            )
            question_paper.total_marks = total_marks

        return question_paper

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error generating questions: {str(e)}"
        )


@app.get("/documents", response_model=List[dict])
async def list_documents():
    """List all uploaded documents."""
    return [
        {
            "document_id": doc_id,
            "filename": info["filename"],
            "file_type": info["file_type"],
            "num_chunks": info["num_chunks"]
        }
        for doc_id, info in uploaded_documents.items()
    ]


@app.delete("/documents/{document_id}")
async def delete_document(document_id: str):
    """Delete a specific document."""
    if document_id not in uploaded_documents:
        raise HTTPException(status_code=404, detail="Document not found")
    
    # Remove file
    file_path = uploaded_documents[document_id]["file_path"]
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # Remove from metadata
    del uploaded_documents[document_id]
    
    return {"message": "Document deleted successfully"}


@app.delete("/documents")
async def clear_all_documents():
    """Clear all uploaded documents and reset the vector store."""
    # Remove all files
    for doc_id, info in uploaded_documents.items():
        file_path = info["file_path"]
        if os.path.exists(file_path):
            os.remove(file_path)
    
    # Clear metadata
    uploaded_documents.clear()
    
    # Clear RAG system
    rag_service.clear_documents()
    
    return {"message": "All documents cleared successfully"}


@app.get("/stats")
async def get_stats():
    """Get statistics about the system."""
    rag_stats = rag_service.get_stats()
    
    return {
        "num_uploaded_documents": len(uploaded_documents),
        "num_indexed_chunks": rag_stats["num_documents"],
        "has_vector_store": rag_stats["has_vector_store"],
        "supported_formats": document_processor.get_supported_extensions()
    }


# Course Structure Management Endpoints

@app.get("/subjects", response_model=List[Subject])
async def get_subjects():
    """Get all subjects."""
    return list(subjects.values())


@app.post("/subjects", response_model=Subject)
async def create_subject(subject_data: SubjectCreate):
    """Create a new subject."""
    subject_id = str(uuid.uuid4())
    now = datetime.now().isoformat()

    subject = Subject(
        id=subject_id,
        name=subject_data.name,
        code=subject_data.code,
        description=subject_data.description,
        created_at=now,
        updated_at=now
    )

    subjects[subject_id] = subject
    return subject


@app.get("/subjects/{subject_id}/units", response_model=List[Unit])
async def get_units(subject_id: str):
    """Get all units for a subject."""
    return [unit for unit in units.values() if unit.subject_id == subject_id]


@app.post("/units", response_model=Unit)
async def create_unit(unit_data: UnitCreate):
    """Create a new unit."""
    if unit_data.subject_id not in subjects:
        raise HTTPException(status_code=404, detail="Subject not found")

    unit_id = str(uuid.uuid4())
    now = datetime.now().isoformat()

    unit = Unit(
        id=unit_id,
        subject_id=unit_data.subject_id,
        name=unit_data.name,
        description=unit_data.description,
        order=unit_data.order,
        created_at=now,
        updated_at=now
    )

    units[unit_id] = unit
    return unit


@app.get("/units/{unit_id}/lessons", response_model=List[Lesson])
async def get_lessons(unit_id: str):
    """Get all lessons for a unit."""
    return [lesson for lesson in lessons.values() if lesson.unit_id == unit_id]


@app.post("/lessons", response_model=Lesson)
async def create_lesson(lesson_data: LessonCreate):
    """Create a new lesson."""
    if lesson_data.unit_id not in units:
        raise HTTPException(status_code=404, detail="Unit not found")

    lesson_id = str(uuid.uuid4())
    now = datetime.now().isoformat()

    lesson = Lesson(
        id=lesson_id,
        unit_id=lesson_data.unit_id,
        name=lesson_data.name,
        description=lesson_data.description,
        order=lesson_data.order,
        learning_objectives=lesson_data.learning_objectives,
        created_at=now,
        updated_at=now
    )

    lessons[lesson_id] = lesson
    return lesson


@app.get("/course-structure", response_model=dict)
async def get_full_course_structure():
    """Get the complete course structure with subjects, units, and lessons."""
    structure = {}

    for subject in subjects.values():
        subject_units = [unit for unit in units.values() if unit.subject_id == subject.id]

        units_with_lessons = []
        for unit in subject_units:
            unit_lessons = [lesson for lesson in lessons.values() if lesson.unit_id == unit.id]
            units_with_lessons.append({
                "id": unit.id,
                "name": unit.name,
                "description": unit.description,
                "order": unit.order,
                "lessons": unit_lessons
            })

        structure[subject.id] = {
            "id": subject.id,
            "name": subject.name,
            "code": subject.code,
            "description": subject.description,
            "units": units_with_lessons
        }

    return structure


@app.delete("/subjects/{subject_id}")
async def delete_subject(subject_id: str):
    """Delete a subject and all its units and lessons."""
    if subject_id not in subjects:
        raise HTTPException(status_code=404, detail="Subject not found")

    # Delete subject
    del subjects[subject_id]

    # Delete all units for this subject
    units_to_delete = [unit_id for unit_id, unit in units.items() if unit.subject_id == subject_id]
    for unit_id in units_to_delete:
        del units[unit_id]

        # Delete all lessons for this unit
        lessons_to_delete = [lesson_id for lesson_id, lesson in lessons.items() if lesson.unit_id == unit_id]
        for lesson_id in lessons_to_delete:
            del lessons[lesson_id]

    return {"message": "Subject and all related units and lessons deleted successfully"}


@app.delete("/units/{unit_id}")
async def delete_unit(unit_id: str):
    """Delete a unit and all its lessons."""
    if unit_id not in units:
        raise HTTPException(status_code=404, detail="Unit not found")

    # Delete unit
    del units[unit_id]

    # Delete all lessons for this unit
    lessons_to_delete = [lesson_id for lesson_id, lesson in lessons.items() if lesson.unit_id == unit_id]
    for lesson_id in lessons_to_delete:
        del lessons[lesson_id]

    return {"message": "Unit and all related lessons deleted successfully"}


@app.delete("/lessons/{lesson_id}")
async def delete_lesson(lesson_id: str):
    """Delete a lesson."""
    if lesson_id not in lessons:
        raise HTTPException(status_code=404, detail="Lesson not found")

    del lessons[lesson_id]
    return {"message": "Lesson deleted successfully"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.api_host,
        port=settings.api_port,
        reload=True
    )
