#!/usr/bin/env fish

# Paperly Backend Start Script for Fish Shell

echo "Starting Paperly Backend API..."
echo "================================"

# Check if virtual environment exists
if not test -d venv
    echo "Virtual environment not found. Creating one..."
    python3 -m venv venv
end

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate.fish

# Install/Update dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Create uploads directory if it doesn't exist
mkdir -p uploads

# Check if .env exists
if not test -f .env
    echo "Creating .env file from .env.example..."
    cp .env.example .env
    echo "⚠️  Please update .env with your API credentials"
end

# Start the server
echo ""
echo "================================"
echo "Starting FastAPI server..."
echo "API will be available at: http://localhost:8000"
echo "API docs: http://localhost:8000/docs"
echo "================================"
echo ""

python main.py
